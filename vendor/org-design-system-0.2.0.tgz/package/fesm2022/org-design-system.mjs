import * as i0 from '@angular/core';
import { input, Directive, viewChild, ChangeDetectionStrategy, Component, model, contentChildren, computed, output, ViewEncapsulation, signal, Injectable, inject } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Tabs, TabList, Tab, TabPanel, TabContent } from '@angular/aria/tabs';
import { RouterLink, RouterLinkActive } from '@angular/router';

/** Styles a native <button> or <a>. Keeps native semantics; no wrapper element. */
class DsButton {
    variant = input('secondary', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.25", type: DsButton, isStandalone: true, selector: "button[dsButton], a[dsButton]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ds-button--primary": "variant() === 'primary'", "class.ds-button--secondary": "variant() === 'secondary'", "class.ds-button--ghost": "variant() === 'ghost'", "class.ds-button--danger": "variant() === 'danger'", "class.ds-button--sm": "size() === 'sm'" }, classAttribute: "ds-button" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsButton, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[dsButton], a[dsButton]',
                    host: {
                        class: 'ds-button',
                        '[class.ds-button--primary]': "variant() === 'primary'",
                        '[class.ds-button--secondary]': "variant() === 'secondary'",
                        '[class.ds-button--ghost]': "variant() === 'ghost'",
                        '[class.ds-button--danger]': "variant() === 'danger'",
                        '[class.ds-button--sm]': "size() === 'sm'",
                    },
                }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }] } });
/**
 * Button styles ship as a component-less stylesheet string so the directive stays
 * attribute-only. DsAppShell injects it once; remotes never ship global CSS.
 */
const DS_BUTTON_STYLES = `
.ds-button{display:inline-flex;align-items:center;gap:var(--ds-space-2);height:32px;padding:0 var(--ds-space-3);
  border-radius:var(--ds-radius-sm);border:1px solid var(--ds-color-border);background:var(--ds-color-surface);
  color:var(--ds-color-text);cursor:pointer;text-decoration:none;font-size:var(--ds-font-size-md);white-space:nowrap}
.ds-button:hover{background:var(--ds-color-surface-sunken)}
.ds-button:disabled{opacity:.55;cursor:not-allowed}
.ds-button--primary{background:var(--ds-color-primary);border-color:var(--ds-color-primary);color:var(--ds-color-primary-contrast)}
.ds-button--primary:hover{filter:brightness(1.08);background:var(--ds-color-primary)}
.ds-button--ghost{border-color:transparent;background:transparent}
.ds-button--danger{background:var(--ds-color-danger);border-color:var(--ds-color-danger);color:#fff}
.ds-button--sm{height:26px;padding:0 var(--ds-space-2);font-size:var(--ds-font-size-sm)}
`;

/** One tab. Its content is a template so ds-tabs controls when it is rendered. */
class DsTab {
    label = input.required(...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    content = viewChild.required('content');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsTab, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.25", type: DsTab, isStandalone: true, selector: "ds-tab", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "content", first: true, predicate: ["content"], descendants: true, isSignal: true }], ngImport: i0, template: `<ng-template #content><ng-content /></ng-template>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsTab, decorators: [{
            type: Component,
            args: [{
                    selector: 'ds-tab',
                    template: `<ng-template #content><ng-content /></ng-template>`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], content: [{ type: i0.ViewChild, args: ['content', { isSignal: true }] }] } });
/**
 * Accessible tabs built on @angular/aria (roving focus, arrow keys, ARIA roles).
 * Panels keep their content once rendered (preserveContent) so state survives tab switches.
 */
class DsTabs {
    selectedIndex = model(0, ...(ngDevMode ? [{ debugName: "selectedIndex" }] : /* istanbul ignore next */ []));
    /** 'underline' (default) or 'contained': grey strip with a white selected tab and panel (case screens). */
    variant = input('underline', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    tabs = contentChildren(DsTab, ...(ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []));
    selectedValue = computed(() => 't' + this.selectedIndex(), ...(ngDevMode ? [{ debugName: "selectedValue" }] : /* istanbul ignore next */ []));
    onSelect(value) {
        if (value)
            this.selectedIndex.set(Number(value.slice(1)));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsTabs, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: DsTabs, isStandalone: true, selector: "ds-tabs", inputs: { selectedIndex: { classPropertyName: "selectedIndex", publicName: "selectedIndex", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedIndex: "selectedIndexChange" }, queries: [{ propertyName: "tabs", predicate: DsTab, isSignal: true }], ngImport: i0, template: `
    <div ngTabs class="ds-tabs" [attr.data-variant]="variant()">
      <div ngTabList class="ds-tabs__list" [selectedTab]="selectedValue()" (selectedTabChange)="onSelect($event)">
        @for (tab of tabs(); track $index) {
          <button ngTab class="ds-tabs__tab" [value]="'t' + $index" [disabled]="tab.disabled()">{{ tab.label() }}</button>
        }
      </div>
      @for (tab of tabs(); track $index) {
        <div ngTabPanel class="ds-tabs__panel" [value]="'t' + $index" [preserveContent]="true">
          <ng-template ngTabContent><ng-container [ngTemplateOutlet]="tab.content()" /></ng-template>
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block}.ds-tabs__list{display:flex;gap:var(--ds-space-1);border-bottom:1px solid var(--ds-color-border)}.ds-tabs__tab{appearance:none;border:0;background:none;padding:var(--ds-space-2) var(--ds-space-3);cursor:pointer;color:var(--ds-color-text-muted);border-bottom:2px solid transparent;margin-bottom:-1px}.ds-tabs__tab[aria-selected=true]{color:var(--ds-color-text);border-bottom-color:var(--ds-color-primary);font-weight:600}.ds-tabs__panel{padding:var(--ds-space-4) 0}.ds-tabs__panel[inert]{display:none}[data-variant=contained] .ds-tabs__list{gap:0;border-bottom:0;padding:var(--ds-space-1) var(--ds-space-2) 0;background:color-mix(in srgb,var(--ds-color-text) 45%,var(--ds-color-surface));border-radius:var(--ds-radius-md) var(--ds-radius-md) 0 0}[data-variant=contained] .ds-tabs__tab{color:var(--ds-color-surface);border:0;margin:0;padding:var(--ds-space-2) var(--ds-space-5);border-radius:var(--ds-radius-sm) var(--ds-radius-sm) 0 0;font-weight:500}[data-variant=contained] .ds-tabs__tab:hover{background:color-mix(in srgb,var(--ds-color-surface) 15%,transparent)}[data-variant=contained] .ds-tabs__tab[aria-selected=true]{background:var(--ds-color-surface);color:var(--ds-color-text);font-weight:600}[data-variant=contained] .ds-tabs__panel{padding:var(--ds-space-4);background:var(--ds-color-surface);border:1px solid var(--ds-color-border);border-top:0;border-radius:0 0 var(--ds-radius-md) var(--ds-radius-md)}\n"], dependencies: [{ kind: "directive", type: Tabs, selector: "[ngTabs]", exportAs: ["ngTabs"] }, { kind: "directive", type: TabList, selector: "[ngTabList]", inputs: ["orientation", "wrap", "softDisabled", "focusMode", "selectionMode", "selectedTab", "disabled"], outputs: ["selectedTabChange"], exportAs: ["ngTabList"] }, { kind: "directive", type: Tab, selector: "[ngTab]", inputs: ["id", "disabled", "value"], exportAs: ["ngTab"] }, { kind: "directive", type: TabPanel, selector: "[ngTabPanel]", inputs: ["id", "value"], exportAs: ["ngTabPanel"] }, { kind: "directive", type: TabContent, selector: "ng-template[ngTabContent]", exportAs: ["ngTabContent"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsTabs, decorators: [{
            type: Component,
            args: [{ selector: 'ds-tabs', imports: [Tabs, TabList, Tab, TabPanel, TabContent, NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div ngTabs class="ds-tabs" [attr.data-variant]="variant()">
      <div ngTabList class="ds-tabs__list" [selectedTab]="selectedValue()" (selectedTabChange)="onSelect($event)">
        @for (tab of tabs(); track $index) {
          <button ngTab class="ds-tabs__tab" [value]="'t' + $index" [disabled]="tab.disabled()">{{ tab.label() }}</button>
        }
      </div>
      @for (tab of tabs(); track $index) {
        <div ngTabPanel class="ds-tabs__panel" [value]="'t' + $index" [preserveContent]="true">
          <ng-template ngTabContent><ng-container [ngTemplateOutlet]="tab.content()" /></ng-template>
        </div>
      }
    </div>
  `, styles: [":host{display:block}.ds-tabs__list{display:flex;gap:var(--ds-space-1);border-bottom:1px solid var(--ds-color-border)}.ds-tabs__tab{appearance:none;border:0;background:none;padding:var(--ds-space-2) var(--ds-space-3);cursor:pointer;color:var(--ds-color-text-muted);border-bottom:2px solid transparent;margin-bottom:-1px}.ds-tabs__tab[aria-selected=true]{color:var(--ds-color-text);border-bottom-color:var(--ds-color-primary);font-weight:600}.ds-tabs__panel{padding:var(--ds-space-4) 0}.ds-tabs__panel[inert]{display:none}[data-variant=contained] .ds-tabs__list{gap:0;border-bottom:0;padding:var(--ds-space-1) var(--ds-space-2) 0;background:color-mix(in srgb,var(--ds-color-text) 45%,var(--ds-color-surface));border-radius:var(--ds-radius-md) var(--ds-radius-md) 0 0}[data-variant=contained] .ds-tabs__tab{color:var(--ds-color-surface);border:0;margin:0;padding:var(--ds-space-2) var(--ds-space-5);border-radius:var(--ds-radius-sm) var(--ds-radius-sm) 0 0;font-weight:500}[data-variant=contained] .ds-tabs__tab:hover{background:color-mix(in srgb,var(--ds-color-surface) 15%,transparent)}[data-variant=contained] .ds-tabs__tab[aria-selected=true]{background:var(--ds-color-surface);color:var(--ds-color-text);font-weight:600}[data-variant=contained] .ds-tabs__panel{padding:var(--ds-space-4);background:var(--ds-color-surface);border:1px solid var(--ds-color-border);border-top:0;border-radius:0 0 var(--ds-radius-md) var(--ds-radius-md)}\n"] }]
        }], propDecorators: { selectedIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedIndex", required: false }] }, { type: i0.Output, args: ["selectedIndexChange"] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], tabs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => DsTab), { isSignal: true }] }] } });

/** Loading placeholder. Announces "Loading" once to assistive tech. */
class DsSkeleton {
    variant = input('text', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    rows = () => Array.from({ length: this.variant() === 'panel' ? 4 : 2 });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsSkeleton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: DsSkeleton, isStandalone: true, selector: "ds-skeleton", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "status", "aria-live": "polite" }, properties: { "attr.data-variant": "variant()" } }, ngImport: i0, template: `
    <span class="ds-visually-hidden">Loading</span>
    @for (_ of rows(); track $index) { <div class="ds-skeleton__bar" [style.width.%]="90 - $index * 12"></div> }
  `, isInline: true, styles: [":host{display:block;padding:var(--ds-space-3) 0}:host([data-variant=\"panel\"]){padding:var(--ds-space-5);border:1px solid var(--ds-color-border);border-radius:var(--ds-radius-md)}.ds-skeleton__bar{height:12px;margin:var(--ds-space-2) 0;border-radius:var(--ds-radius-sm);background:linear-gradient(90deg,var(--ds-color-surface-sunken),var(--ds-color-border),var(--ds-color-surface-sunken));background-size:200% 100%;animation:ds-shimmer 1.4s infinite}@keyframes ds-shimmer{to{background-position:-200% 0}}@media(prefers-reduced-motion:reduce){.ds-skeleton__bar{animation:none}}.ds-visually-hidden{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsSkeleton, decorators: [{
            type: Component,
            args: [{ selector: 'ds-skeleton', changeDetection: ChangeDetectionStrategy.OnPush, host: { role: 'status', 'aria-live': 'polite', '[attr.data-variant]': 'variant()' }, template: `
    <span class="ds-visually-hidden">Loading</span>
    @for (_ of rows(); track $index) { <div class="ds-skeleton__bar" [style.width.%]="90 - $index * 12"></div> }
  `, styles: [":host{display:block;padding:var(--ds-space-3) 0}:host([data-variant=\"panel\"]){padding:var(--ds-space-5);border:1px solid var(--ds-color-border);border-radius:var(--ds-radius-md)}.ds-skeleton__bar{height:12px;margin:var(--ds-space-2) 0;border-radius:var(--ds-radius-sm);background:linear-gradient(90deg,var(--ds-color-surface-sunken),var(--ds-color-border),var(--ds-color-surface-sunken));background-size:200% 100%;animation:ds-shimmer 1.4s infinite}@keyframes ds-shimmer{to{background-position:-200% 0}}@media(prefers-reduced-motion:reduce){.ds-skeleton__bar{animation:none}}.ds-visually-hidden{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }] } });

const ICONS = { warning: '⚠', info: 'ℹ', empty: '○', lock: '🔒' };
/** Empty, error or "no access" state with an optional single action. */
class DsEmptyState {
    icon = input('info', ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    heading = input.required(...(ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []));
    message = input(...(ngDevMode ? [undefined, { debugName: "message" }] : /* istanbul ignore next */ []));
    actionLabel = input(...(ngDevMode ? [undefined, { debugName: "actionLabel" }] : /* istanbul ignore next */ []));
    action = output();
    glyph = () => ICONS[this.icon()] ?? '';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsEmptyState, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: DsEmptyState, isStandalone: true, selector: "ds-empty-state", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, heading: { classPropertyName: "heading", publicName: "heading", isSignal: true, isRequired: true, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, actionLabel: { classPropertyName: "actionLabel", publicName: "actionLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { action: "action" }, ngImport: i0, template: `
    <div class="ds-empty__icon" aria-hidden="true">{{ glyph() }}</div>
    <h2 class="ds-empty__heading">{{ heading() }}</h2>
    @if (message()) { <p class="ds-empty__message">{{ message() }}</p> }
    @if (actionLabel()) { <button dsButton variant="primary" type="button" (click)="action.emit()">{{ actionLabel() }}</button> }
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;align-items:center;text-align:center;gap:var(--ds-space-2);padding:var(--ds-space-6) var(--ds-space-4);border:1px dashed var(--ds-color-border);border-radius:var(--ds-radius-md);background:var(--ds-color-surface)}.ds-empty__icon{font-size:28px;color:var(--ds-color-warning)}.ds-empty__heading{margin:0;font-size:var(--ds-font-size-lg)}.ds-empty__message{margin:0;color:var(--ds-color-text-muted);max-width:48ch}\n"], dependencies: [{ kind: "directive", type: DsButton, selector: "button[dsButton], a[dsButton]", inputs: ["variant", "size"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsEmptyState, decorators: [{
            type: Component,
            args: [{ selector: 'ds-empty-state', imports: [DsButton], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="ds-empty__icon" aria-hidden="true">{{ glyph() }}</div>
    <h2 class="ds-empty__heading">{{ heading() }}</h2>
    @if (message()) { <p class="ds-empty__message">{{ message() }}</p> }
    @if (actionLabel()) { <button dsButton variant="primary" type="button" (click)="action.emit()">{{ actionLabel() }}</button> }
  `, styles: [":host{display:flex;flex-direction:column;align-items:center;text-align:center;gap:var(--ds-space-2);padding:var(--ds-space-6) var(--ds-space-4);border:1px dashed var(--ds-color-border);border-radius:var(--ds-radius-md);background:var(--ds-color-surface)}.ds-empty__icon{font-size:28px;color:var(--ds-color-warning)}.ds-empty__heading{margin:0;font-size:var(--ds-font-size-lg)}.ds-empty__message{margin:0;color:var(--ds-color-text-muted);max-width:48ch}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], heading: [{ type: i0.Input, args: [{ isSignal: true, alias: "heading", required: true }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], actionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "actionLabel", required: false }] }], action: [{ type: i0.Output, args: ["action"] }] } });

/**
 * Layout primitive for app chrome: header, left nav, main.
 * Slots: [dsAppShellBrand], [dsAppShellHeader], [dsAppShellNav], default (main content).
 * Owns no data and no routing.
 */
class DsAppShell {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsAppShell, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.25", type: DsAppShell, isStandalone: true, selector: "ds-app-shell", ngImport: i0, template: `
    <a class="ds-shell__skip" href="#ds-main">Skip to content</a>
    <header class="ds-shell__header">
      <div class="ds-shell__brand"><ng-content select="[dsAppShellBrand]" /></div>
      <div class="ds-shell__header-content"><ng-content select="[dsAppShellHeader]" /></div>
    </header>
    <nav class="ds-shell__nav" aria-label="Primary"><ng-content select="[dsAppShellNav]" /></nav>
    <main class="ds-shell__main" id="ds-main" tabindex="-1"><ng-content /></main>
  `, isInline: true, styles: ["ds-app-shell{display:grid;grid-template-columns:var(--ds-layout-nav-width) 1fr;grid-template-rows:var(--ds-layout-header-height) 1fr;grid-template-areas:\"header header\" \"nav main\";height:100vh}.ds-shell__header{grid-area:header;display:flex;align-items:center;gap:var(--ds-space-4);padding:0 var(--ds-space-4);background:var(--ds-color-surface);border-bottom:1px solid var(--ds-color-border)}.ds-shell__brand{font-weight:700;width:calc(var(--ds-layout-nav-width) - var(--ds-space-4) * 2)}.ds-shell__header-content{flex:1;display:flex;align-items:center;gap:var(--ds-space-3)}.ds-shell__nav{grid-area:nav;overflow:auto;padding:var(--ds-space-3);background:var(--ds-color-surface);border-right:1px solid var(--ds-color-border)}.ds-shell__main{grid-area:main;overflow:auto;padding:var(--ds-space-5);outline:none}.ds-shell__skip{position:absolute;left:-9999px}.ds-shell__skip:focus{left:var(--ds-space-2);top:var(--ds-space-2);z-index:10;background:var(--ds-color-surface);padding:var(--ds-space-2)}@media(max-width:720px){ds-app-shell{grid-template-columns:1fr;grid-template-rows:var(--ds-layout-header-height) auto 1fr;grid-template-areas:\"header\" \"nav\" \"main\"}.ds-shell__brand{width:auto}}.ds-button{display:inline-flex;align-items:center;gap:var(--ds-space-2);height:32px;padding:0 var(--ds-space-3);border-radius:var(--ds-radius-sm);border:1px solid var(--ds-color-border);background:var(--ds-color-surface);color:var(--ds-color-text);cursor:pointer;text-decoration:none;font-size:var(--ds-font-size-md);white-space:nowrap}.ds-button:hover{background:var(--ds-color-surface-sunken)}.ds-button:disabled{opacity:.55;cursor:not-allowed}.ds-button--primary{background:var(--ds-color-primary);border-color:var(--ds-color-primary);color:var(--ds-color-primary-contrast)}.ds-button--primary:hover{filter:brightness(1.08);background:var(--ds-color-primary)}.ds-button--ghost{border-color:transparent;background:transparent}.ds-button--danger{background:var(--ds-color-danger);border-color:var(--ds-color-danger);color:#fff}.ds-button--sm{height:26px;padding:0 var(--ds-space-2);font-size:var(--ds-font-size-sm)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsAppShell, decorators: [{
            type: Component,
            args: [{ selector: 'ds-app-shell', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: `
    <a class="ds-shell__skip" href="#ds-main">Skip to content</a>
    <header class="ds-shell__header">
      <div class="ds-shell__brand"><ng-content select="[dsAppShellBrand]" /></div>
      <div class="ds-shell__header-content"><ng-content select="[dsAppShellHeader]" /></div>
    </header>
    <nav class="ds-shell__nav" aria-label="Primary"><ng-content select="[dsAppShellNav]" /></nav>
    <main class="ds-shell__main" id="ds-main" tabindex="-1"><ng-content /></main>
  `, styles: ["ds-app-shell{display:grid;grid-template-columns:var(--ds-layout-nav-width) 1fr;grid-template-rows:var(--ds-layout-header-height) 1fr;grid-template-areas:\"header header\" \"nav main\";height:100vh}.ds-shell__header{grid-area:header;display:flex;align-items:center;gap:var(--ds-space-4);padding:0 var(--ds-space-4);background:var(--ds-color-surface);border-bottom:1px solid var(--ds-color-border)}.ds-shell__brand{font-weight:700;width:calc(var(--ds-layout-nav-width) - var(--ds-space-4) * 2)}.ds-shell__header-content{flex:1;display:flex;align-items:center;gap:var(--ds-space-3)}.ds-shell__nav{grid-area:nav;overflow:auto;padding:var(--ds-space-3);background:var(--ds-color-surface);border-right:1px solid var(--ds-color-border)}.ds-shell__main{grid-area:main;overflow:auto;padding:var(--ds-space-5);outline:none}.ds-shell__skip{position:absolute;left:-9999px}.ds-shell__skip:focus{left:var(--ds-space-2);top:var(--ds-space-2);z-index:10;background:var(--ds-color-surface);padding:var(--ds-space-2)}@media(max-width:720px){ds-app-shell{grid-template-columns:1fr;grid-template-rows:var(--ds-layout-header-height) auto 1fr;grid-template-areas:\"header\" \"nav\" \"main\"}.ds-shell__brand{width:auto}}.ds-button{display:inline-flex;align-items:center;gap:var(--ds-space-2);height:32px;padding:0 var(--ds-space-3);border-radius:var(--ds-radius-sm);border:1px solid var(--ds-color-border);background:var(--ds-color-surface);color:var(--ds-color-text);cursor:pointer;text-decoration:none;font-size:var(--ds-font-size-md);white-space:nowrap}.ds-button:hover{background:var(--ds-color-surface-sunken)}.ds-button:disabled{opacity:.55;cursor:not-allowed}.ds-button--primary{background:var(--ds-color-primary);border-color:var(--ds-color-primary);color:var(--ds-color-primary-contrast)}.ds-button--primary:hover{filter:brightness(1.08);background:var(--ds-color-primary)}.ds-button--ghost{border-color:transparent;background:transparent}.ds-button--danger{background:var(--ds-color-danger);border-color:var(--ds-color-danger);color:#fff}.ds-button--sm{height:26px;padding:0 var(--ds-space-2);font-size:var(--ds-font-size-sm)}\n"] }]
        }] });

/** Vertical navigation list, grouped. Router-aware but data-free. */
class DsNavList {
    items = input.required(...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    groups = () => {
        const map = new Map();
        for (const item of this.items())
            map.set(item.group ?? '', [...(map.get(item.group ?? '') ?? []), item]);
        return [...map].map(([name, items]) => ({ name, items }));
    };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsNavList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: DsNavList, isStandalone: true, selector: "ds-nav-list", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    @for (group of groups(); track group.name) {
      @if (group.name) { <div class="ds-nav__group">{{ group.name }}</div> }
      <ul>
        @for (item of group.items; track item.path) {
          <li><a [routerLink]="item.path" routerLinkActive="ds-nav__link--active" [routerLinkActiveOptions]="{ exact: item.path === '/' }" ariaCurrentWhenActive="page" class="ds-nav__link">
            {{ item.label }} @if (item.badge) { <span class="ds-nav__badge">{{ item.badge }}</span> }
          </a></li>
        }
      </ul>
    }
  `, isInline: true, styles: [":host{display:block}ul{list-style:none;margin:0 0 var(--ds-space-3);padding:0}.ds-nav__group{font-size:var(--ds-font-size-sm);text-transform:uppercase;letter-spacing:.04em;color:var(--ds-color-text-muted);padding:var(--ds-space-2) var(--ds-space-2) var(--ds-space-1)}.ds-nav__link{display:flex;justify-content:space-between;padding:var(--ds-space-2);border-radius:var(--ds-radius-sm);color:var(--ds-color-text);text-decoration:none}.ds-nav__link:hover{background:var(--ds-color-surface-sunken)}.ds-nav__link--active{background:var(--ds-color-surface-sunken);font-weight:600;box-shadow:inset 3px 0 0 var(--ds-color-primary)}.ds-nav__badge{font-size:var(--ds-font-size-sm);color:var(--ds-color-text-muted)}\n"], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsNavList, decorators: [{
            type: Component,
            args: [{ selector: 'ds-nav-list', imports: [RouterLink, RouterLinkActive], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @for (group of groups(); track group.name) {
      @if (group.name) { <div class="ds-nav__group">{{ group.name }}</div> }
      <ul>
        @for (item of group.items; track item.path) {
          <li><a [routerLink]="item.path" routerLinkActive="ds-nav__link--active" [routerLinkActiveOptions]="{ exact: item.path === '/' }" ariaCurrentWhenActive="page" class="ds-nav__link">
            {{ item.label }} @if (item.badge) { <span class="ds-nav__badge">{{ item.badge }}</span> }
          </a></li>
        }
      </ul>
    }
  `, styles: [":host{display:block}ul{list-style:none;margin:0 0 var(--ds-space-3);padding:0}.ds-nav__group{font-size:var(--ds-font-size-sm);text-transform:uppercase;letter-spacing:.04em;color:var(--ds-color-text-muted);padding:var(--ds-space-2) var(--ds-space-2) var(--ds-space-1)}.ds-nav__link{display:flex;justify-content:space-between;padding:var(--ds-space-2);border-radius:var(--ds-radius-sm);color:var(--ds-color-text);text-decoration:none}.ds-nav__link:hover{background:var(--ds-color-surface-sunken)}.ds-nav__link--active{background:var(--ds-color-surface-sunken);font-weight:600;box-shadow:inset 3px 0 0 var(--ds-color-primary)}.ds-nav__badge{font-size:var(--ds-font-size-sm);color:var(--ds-color-text-muted)}\n"] }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }] } });

class DsBadge {
    tone = input('neutral', ...(ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsBadge, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.25", type: DsBadge, isStandalone: true, selector: "ds-badge", inputs: { tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-tone": "tone()" } }, ngImport: i0, template: `<ng-content />`, isInline: true, styles: [":host{display:inline-flex;align-items:center;height:20px;padding:0 var(--ds-space-2);border-radius:999px;font-size:var(--ds-font-size-sm);border:1px solid var(--ds-color-border);color:var(--ds-color-text-muted)}:host([data-tone=\"info\"]){color:var(--ds-color-primary);border-color:currentColor}:host([data-tone=\"success\"]){color:var(--ds-color-success);border-color:currentColor}:host([data-tone=\"warning\"]){color:var(--ds-color-warning);border-color:currentColor}:host([data-tone=\"danger\"]){color:var(--ds-color-danger);border-color:currentColor}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsBadge, decorators: [{
            type: Component,
            args: [{ selector: 'ds-badge', changeDetection: ChangeDetectionStrategy.OnPush, host: { '[attr.data-tone]': 'tone()' }, template: `<ng-content />`, styles: [":host{display:inline-flex;align-items:center;height:20px;padding:0 var(--ds-space-2);border-radius:999px;font-size:var(--ds-font-size-sm);border:1px solid var(--ds-color-border);color:var(--ds-color-text-muted)}:host([data-tone=\"info\"]){color:var(--ds-color-primary);border-color:currentColor}:host([data-tone=\"success\"]){color:var(--ds-color-success);border-color:currentColor}:host([data-tone=\"warning\"]){color:var(--ds-color-warning);border-color:currentColor}:host([data-tone=\"danger\"]){color:var(--ds-color-danger);border-color:currentColor}\n"] }]
        }], propDecorators: { tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }] } });

/**
 * Toast queue. providedIn root + design-system as a federation singleton means
 * every remote pushes to the one host the shell renders.
 */
class DsNotificationService {
    nextId = 1;
    items = signal([], ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    show(message, tone = 'info', durationMs = 5000) {
        const id = this.nextId++;
        this.items.update((list) => [...list, { id, tone, message }]);
        if (durationMs > 0)
            setTimeout(() => this.dismiss(id), durationMs);
    }
    dismiss(id) {
        this.items.update((list) => list.filter((n) => n.id !== id));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsNotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsNotificationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsNotificationService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Render exactly once, in the shell. */
class DsNotificationHost {
    service = inject(DsNotificationService);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsNotificationHost, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: DsNotificationHost, isStandalone: true, selector: "ds-notification-host", host: { attributes: { "aria-live": "polite", "role": "region", "aria-label": "Notifications" } }, ngImport: i0, template: `
    @for (n of service.items(); track n.id) {
      <div class="ds-toast" [attr.data-tone]="n.tone">
        <span>{{ n.message }}</span>
        <button type="button" class="ds-toast__close" aria-label="Dismiss" (click)="service.dismiss(n.id)">×</button>
      </div>
    }
  `, isInline: true, styles: [":host{position:fixed;right:var(--ds-space-4);bottom:var(--ds-space-4);display:flex;flex-direction:column;gap:var(--ds-space-2);z-index:1000}.ds-toast{display:flex;gap:var(--ds-space-3);align-items:center;min-width:280px;padding:var(--ds-space-3);background:var(--ds-color-surface);border:1px solid var(--ds-color-border);border-left-width:4px;border-radius:var(--ds-radius-md);box-shadow:0 4px 16px #0000001f}.ds-toast[data-tone=success]{border-left-color:var(--ds-color-success)}.ds-toast[data-tone=warning]{border-left-color:var(--ds-color-warning)}.ds-toast[data-tone=danger]{border-left-color:var(--ds-color-danger)}.ds-toast[data-tone=info]{border-left-color:var(--ds-color-primary)}.ds-toast span{flex:1}.ds-toast__close{border:0;background:none;cursor:pointer;font-size:18px;color:var(--ds-color-text-muted)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsNotificationHost, decorators: [{
            type: Component,
            args: [{ selector: 'ds-notification-host', changeDetection: ChangeDetectionStrategy.OnPush, host: { 'aria-live': 'polite', role: 'region', 'aria-label': 'Notifications' }, template: `
    @for (n of service.items(); track n.id) {
      <div class="ds-toast" [attr.data-tone]="n.tone">
        <span>{{ n.message }}</span>
        <button type="button" class="ds-toast__close" aria-label="Dismiss" (click)="service.dismiss(n.id)">×</button>
      </div>
    }
  `, styles: [":host{position:fixed;right:var(--ds-space-4);bottom:var(--ds-space-4);display:flex;flex-direction:column;gap:var(--ds-space-2);z-index:1000}.ds-toast{display:flex;gap:var(--ds-space-3);align-items:center;min-width:280px;padding:var(--ds-space-3);background:var(--ds-color-surface);border:1px solid var(--ds-color-border);border-left-width:4px;border-radius:var(--ds-radius-md);box-shadow:0 4px 16px #0000001f}.ds-toast[data-tone=success]{border-left-color:var(--ds-color-success)}.ds-toast[data-tone=warning]{border-left-color:var(--ds-color-warning)}.ds-toast[data-tone=danger]{border-left-color:var(--ds-color-danger)}.ds-toast[data-tone=info]{border-left-color:var(--ds-color-primary)}.ds-toast span{flex:1}.ds-toast__close{border:0;background:none;cursor:pointer;font-size:18px;color:var(--ds-color-text-muted)}\n"] }]
        }] });

/** Labelled native <select>. Native keeps mobile and screen-reader behaviour for free. */
class DsSelect {
    label = input.required(...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    hideLabel = input(false, ...(ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []));
    options = input.required(...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    value = model('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsSelect, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: DsSelect, isStandalone: true, selector: "ds-select", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, hideLabel: { classPropertyName: "hideLabel", publicName: "hideLabel", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, ngImport: i0, template: `
    <label class="ds-select">
      <span class="ds-select__label" [class.ds-select__label--hidden]="hideLabel()">{{ label() }}</span>
      <select [value]="value()" (change)="value.set($any($event.target).value)">
        @for (o of options(); track o.value) { <option [value]="o.value" [selected]="o.value === value()">{{ o.label }}</option> }
      </select>
    </label>
  `, isInline: true, styles: [".ds-select{display:inline-flex;align-items:center;gap:var(--ds-space-2);font-size:var(--ds-font-size-sm)}.ds-select__label{color:var(--ds-color-text-muted)}.ds-select__label--hidden{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}select{height:30px;padding:0 var(--ds-space-2);border:1px solid var(--ds-color-border);border-radius:var(--ds-radius-sm);background:var(--ds-color-surface)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsSelect, decorators: [{
            type: Component,
            args: [{ selector: 'ds-select', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <label class="ds-select">
      <span class="ds-select__label" [class.ds-select__label--hidden]="hideLabel()">{{ label() }}</span>
      <select [value]="value()" (change)="value.set($any($event.target).value)">
        @for (o of options(); track o.value) { <option [value]="o.value" [selected]="o.value === value()">{{ o.label }}</option> }
      </select>
    </label>
  `, styles: [".ds-select{display:inline-flex;align-items:center;gap:var(--ds-space-2);font-size:var(--ds-font-size-sm)}.ds-select__label{color:var(--ds-color-text-muted)}.ds-select__label--hidden{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}select{height:30px;padding:0 var(--ds-space-2);border:1px solid var(--ds-color-border);border-radius:var(--ds-radius-sm);background:var(--ds-color-surface)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], hideLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideLabel", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }] } });

class DsSearchField {
    label = input.required(...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    value = model('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    search = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsSearchField, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.25", type: DsSearchField, isStandalone: true, selector: "ds-search-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", search: "search" }, ngImport: i0, template: `
    <form role="search" (submit)="$event.preventDefault(); search.emit(value())">
      <label class="ds-search">
        <span class="ds-search__label">{{ label() }}</span>
        <input type="search" [placeholder]="placeholder()" [value]="value()" (input)="value.set($any($event.target).value)" />
      </label>
    </form>
  `, isInline: true, styles: [":host{flex:1;max-width:520px}.ds-search__label{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}input{width:100%;height:34px;padding:0 var(--ds-space-3);border:1px solid var(--ds-color-border);border-radius:var(--ds-radius-md);background:var(--ds-color-surface-sunken)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DsSearchField, decorators: [{
            type: Component,
            args: [{ selector: 'ds-search-field', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <form role="search" (submit)="$event.preventDefault(); search.emit(value())">
      <label class="ds-search">
        <span class="ds-search__label">{{ label() }}</span>
        <input type="search" [placeholder]="placeholder()" [value]="value()" (input)="value.set($any($event.target).value)" />
      </label>
    </form>
  `, styles: [":host{flex:1;max-width:520px}.ds-search__label{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}input{width:100%;height:34px;padding:0 var(--ds-space-3);border:1px solid var(--ds-color-border);border-radius:var(--ds-radius-md);background:var(--ds-color-surface-sunken)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], search: [{ type: i0.Output, args: ["search"] }] } });

/*
 * @org/design-system public API.
 * Presentational only: no HTTP, no routing, no business types.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DS_BUTTON_STYLES, DsAppShell, DsBadge, DsButton, DsEmptyState, DsNavList, DsNotificationHost, DsNotificationService, DsSearchField, DsSelect, DsSkeleton, DsTab, DsTabs };
//# sourceMappingURL=org-design-system.mjs.map
