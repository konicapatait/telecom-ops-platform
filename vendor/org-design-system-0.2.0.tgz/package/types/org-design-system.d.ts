import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';

type DsButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
/** Styles a native <button> or <a>. Keeps native semantics; no wrapper element. */
declare class DsButton {
    readonly variant: _angular_core.InputSignal<DsButtonVariant>;
    readonly size: _angular_core.InputSignal<"sm" | "md">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsButton, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DsButton, "button[dsButton], a[dsButton]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Button styles ship as a component-less stylesheet string so the directive stays
 * attribute-only. DsAppShell injects it once; remotes never ship global CSS.
 */
declare const DS_BUTTON_STYLES = "\n.ds-button{display:inline-flex;align-items:center;gap:var(--ds-space-2);height:32px;padding:0 var(--ds-space-3);\n  border-radius:var(--ds-radius-sm);border:1px solid var(--ds-color-border);background:var(--ds-color-surface);\n  color:var(--ds-color-text);cursor:pointer;text-decoration:none;font-size:var(--ds-font-size-md);white-space:nowrap}\n.ds-button:hover{background:var(--ds-color-surface-sunken)}\n.ds-button:disabled{opacity:.55;cursor:not-allowed}\n.ds-button--primary{background:var(--ds-color-primary);border-color:var(--ds-color-primary);color:var(--ds-color-primary-contrast)}\n.ds-button--primary:hover{filter:brightness(1.08);background:var(--ds-color-primary)}\n.ds-button--ghost{border-color:transparent;background:transparent}\n.ds-button--danger{background:var(--ds-color-danger);border-color:var(--ds-color-danger);color:#fff}\n.ds-button--sm{height:26px;padding:0 var(--ds-space-2);font-size:var(--ds-font-size-sm)}\n";

/** One tab. Its content is a template so ds-tabs controls when it is rendered. */
declare class DsTab {
    readonly label: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly content: _angular_core.Signal<TemplateRef<unknown>>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsTab, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsTab, "ds-tab", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
/**
 * Accessible tabs built on @angular/aria (roving focus, arrow keys, ARIA roles).
 * Panels keep their content once rendered (preserveContent) so state survives tab switches.
 */
declare class DsTabs {
    readonly selectedIndex: _angular_core.ModelSignal<number>;
    /** 'underline' (default) or 'contained': grey strip with a white selected tab and panel (case screens). */
    readonly variant: _angular_core.InputSignal<"underline" | "contained">;
    protected readonly tabs: _angular_core.Signal<readonly DsTab[]>;
    protected readonly selectedValue: _angular_core.Signal<string>;
    protected onSelect(value: string | undefined): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsTabs, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsTabs, "ds-tabs", never, { "selectedIndex": { "alias": "selectedIndex"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, { "selectedIndex": "selectedIndexChange"; }, ["tabs"], never, true, never>;
}

/** Loading placeholder. Announces "Loading" once to assistive tech. */
declare class DsSkeleton {
    readonly variant: _angular_core.InputSignal<"text" | "panel">;
    protected readonly rows: () => unknown[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsSkeleton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsSkeleton, "ds-skeleton", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Empty, error or "no access" state with an optional single action. */
declare class DsEmptyState {
    readonly icon: _angular_core.InputSignal<"warning" | "info" | "empty" | "lock">;
    readonly heading: _angular_core.InputSignal<string>;
    readonly message: _angular_core.InputSignal<string | undefined>;
    readonly actionLabel: _angular_core.InputSignal<string | undefined>;
    readonly action: _angular_core.OutputEmitterRef<void>;
    protected glyph: () => string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsEmptyState, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsEmptyState, "ds-empty-state", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": true; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, never, true, never>;
}

/**
 * Layout primitive for app chrome: header, left nav, main.
 * Slots: [dsAppShellBrand], [dsAppShellHeader], [dsAppShellNav], default (main content).
 * Owns no data and no routing.
 */
declare class DsAppShell {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsAppShell, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsAppShell, "ds-app-shell", never, {}, {}, never, ["[dsAppShellBrand]", "[dsAppShellHeader]", "[dsAppShellNav]", "*"], true, never>;
}

interface DsNavItem {
    label: string;
    path: string;
    group?: string;
    badge?: string;
}
/** Vertical navigation list, grouped. Router-aware but data-free. */
declare class DsNavList {
    readonly items: _angular_core.InputSignal<DsNavItem[]>;
    protected groups: () => {
        name: string;
        items: DsNavItem[];
    }[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsNavList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsNavList, "ds-nav-list", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

type DsBadgeTone = 'neutral' | 'info' | 'success' | 'warning' | 'danger';
declare class DsBadge {
    readonly tone: _angular_core.InputSignal<DsBadgeTone>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsBadge, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsBadge, "ds-badge", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface DsNotification {
    id: number;
    tone: 'info' | 'success' | 'warning' | 'danger';
    message: string;
}
/**
 * Toast queue. providedIn root + design-system as a federation singleton means
 * every remote pushes to the one host the shell renders.
 */
declare class DsNotificationService {
    private nextId;
    readonly items: _angular_core.WritableSignal<DsNotification[]>;
    show(message: string, tone?: DsNotification['tone'], durationMs?: number): void;
    dismiss(id: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsNotificationService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DsNotificationService>;
}

/** Render exactly once, in the shell. */
declare class DsNotificationHost {
    protected readonly service: DsNotificationService;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsNotificationHost, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsNotificationHost, "ds-notification-host", never, {}, {}, never, never, true, never>;
}

interface DsSelectOption {
    value: string;
    label: string;
}
/** Labelled native <select>. Native keeps mobile and screen-reader behaviour for free. */
declare class DsSelect {
    readonly label: _angular_core.InputSignal<string>;
    readonly hideLabel: _angular_core.InputSignal<boolean>;
    readonly options: _angular_core.InputSignal<DsSelectOption[]>;
    readonly value: _angular_core.ModelSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsSelect, "ds-select", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "hideLabel": { "alias": "hideLabel"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

declare class DsSearchField {
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly value: _angular_core.ModelSignal<string>;
    readonly search: _angular_core.OutputEmitterRef<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DsSearchField, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DsSearchField, "ds-search-field", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "search": "search"; }, never, never, true, never>;
}

export { DS_BUTTON_STYLES, DsAppShell, DsBadge, DsButton, DsEmptyState, DsNavList, DsNotificationHost, DsNotificationService, DsSearchField, DsSelect, DsSkeleton, DsTab, DsTabs };
export type { DsBadgeTone, DsButtonVariant, DsNavItem, DsNotification, DsSelectOption };
//# sourceMappingURL=org-design-system.d.ts.map
